/**
 * app.js
 * ──────────────────────────────────────────────────────────────────────────────
 * Express application entry point.
 *
 * Middleware stack (in order):
 *   helmet        → Security headers
 *   morgan        → HTTP request logging
 *   json parser   → Parse application/json bodies
 *   rateLimit     → Prevent abuse (100 req/min per IP)
 *   routes        → Business logic
 *   404 handler   → Unknown routes
 *   error handler → Centralised error formatting
 */

"use strict";

require("dotenv").config();

const express    = require("express");
const helmet     = require("helmet");
const morgan     = require("morgan");
const rateLimit  = require("express-rate-limit");

const { testConnection } = require("./db/pool");
const analyticsRoutes    = require("./routes/analytics");

// ─── App Initialisation ───────────────────────────────────────────────────────

const app  = express();
const PORT = parseInt(process.env.PORT || "3000", 10);

// ─── Security Middleware ──────────────────────────────────────────────────────

// Sets recommended security headers (X-Frame-Options, HSTS, etc.)
app.use(helmet());

// ─── Logging ──────────────────────────────────────────────────────────────────

// "combined" in production, "dev" in development
const logFormat = process.env.NODE_ENV === "production" ? "combined" : "dev";
app.use(morgan(logFormat));

// ─── Body Parsing ─────────────────────────────────────────────────────────────

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));

// ─── Rate Limiting ────────────────────────────────────────────────────────────

const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS      || "60000",  10),
  max:      parseInt(process.env.RATE_LIMIT_MAX_REQUESTS   || "100",    10),
  standardHeaders: true,  // Return rate limit info in RateLimit-* headers
  legacyHeaders:   false, // Disable X-RateLimit-* headers
  message: {
    success: false,
    error:   "Too many requests. Please try again later.",
  },
});

app.use(limiter);

// ─── API Routes ───────────────────────────────────────────────────────────────

// All routes are prefixed with /api/v1
app.use("/api/v1", analyticsRoutes);

// Root redirect for discoverability
app.get("/", (req, res) => {
  res.json({
    name:    "Campaign Analytics API",
    version: "1.0.0",
    docs:    "/api/v1/health",
    endpoints: [
      "GET  /api/v1/health",
      "GET  /api/v1/analytics?user_id=&role=&[month=]&[geo=]&[vertical=]&[os=]",
      "POST /api/v1/analytics/cache/flush",
    ],
  });
});

// ─── 404 Handler ──────────────────────────────────────────────────────────────

app.use((req, res) => {
  res.status(404).json({
    success: false,
    error:   `Route not found: ${req.method} ${req.originalUrl}`,
  });
});

// ─── Global Error Handler ─────────────────────────────────────────────────────

// Express identifies error handlers by their 4-argument signature (err, req, res, next)
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error("[GlobalErrorHandler]", err);
  res.status(err.status || 500).json({
    success: false,
    error:   err.message || "Internal server error",
    detail:  process.env.NODE_ENV === "development" ? err.stack : undefined,
  });
});

// ─── Server Startup ───────────────────────────────────────────────────────────

async function start() {
  // Verify DB connectivity before accepting traffic
  await testConnection();

  app.listen(PORT, () => {
    console.log(`\n🚀 Campaign Analytics API running on port ${PORT}`);
    console.log(`   Environment : ${process.env.NODE_ENV || "development"}`);
    console.log(`   Base URL    : http://localhost:${PORT}/api/v1`);
    console.log(`   Health      : http://localhost:${PORT}/api/v1/health\n`);
  });
}

// Graceful shutdown on SIGTERM (Docker, Kubernetes)
process.on("SIGTERM", () => {
  console.log("SIGTERM received — shutting down gracefully");
  process.exit(0);
});

// Unhandled promise rejections — log and exit (let the orchestrator restart)
process.on("unhandledRejection", (reason) => {
  console.error("Unhandled Rejection:", reason);
  process.exit(1);
});

start().catch((err) => {
  console.error("Startup failed:", err);
  process.exit(1);
});

module.exports = app; // Export for testing
