# Campaign Analytics API

Production-ready REST API for campaign performance analytics with revenue calculation, role-based access, and publisher ranking.

---

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env with your MySQL credentials

# 3. Bootstrap the database (creates tables + seed data)
npm run db:setup

# 4. Start the server
npm start         # production
npm run dev       # development (nodemon)
```

---

## Project Structure

```
src/
├── app.js                         # Express entry point + middleware stack
├── db/
│   └── pool.js                    # MySQL2 connection pool
├── controllers/
│   └── analyticsController.js     # Request/response orchestration
├── services/
│   ├── accessService.js           # RBAC → resolves allowed pub_ids
│   └── analyticsService.js        # GEO / Vertical / OS query engine
├── routes/
│   └── analytics.js               # Route → middleware → controller wiring
├── middleware/
│   └── rbac.js                    # Role validation + filter parsing
└── utils/
    ├── cache.js                   # node-cache wrapper
    └── queryBuilder.js            # Parameterised WHERE clause builder
sql/
└── setup.js                       # Schema + index bootstrap script
```

---

## API Reference

### `GET /api/v1/analytics`

Returns top GEOs, Verticals, and OS categories with ranked publishers.

#### Query Parameters

| Param      | Required | Type   | Description                                      |
|------------|----------|--------|--------------------------------------------------|
| `user_id`  | ✅       | number | The requesting user's ID                         |
| `role`     | ✅       | string | `publisher` \| `publisher_manager` \| `admin`    |
| `month`    | ❌       | string | Filter by month: `YYYY-MM`                       |
| `geo`      | ❌       | string | Filter by country code: `US`, `IN`, `MX`…       |
| `vertical` | ❌       | string | Filter by vertical: `Finance`, `Gaming`…         |
| `os`       | ❌       | string | Filter by OS: `Android`, `iOS`                   |
| `page`     | ❌       | number | Publisher page (default: 1)                      |
| `page_size`| ❌       | number | Publishers per category page (default: 15, max 100) |

#### Example Requests

```bash
# Admin — full report for January 2024
GET /api/v1/analytics?user_id=1&role=admin&month=2024-01

# Publisher — own data only
GET /api/v1/analytics?user_id=42&role=publisher

# Manager — own + assigned publishers, filtered by GEO
GET /api/v1/analytics?user_id=100&role=publisher_manager&geo=US
```

#### Response

```json
{
  "success": true,
  "data": {
    "geo": [
      {
        "geo": "US",
        "total_revenue": 2700.0,
        "top_publishers": [
          { "pub_id": 1, "revenue": 1350.0, "rank": 1 },
          { "pub_id": 4, "revenue": 1350.0, "rank": 1 }
        ]
      }
    ],
    "vertical": [
      {
        "vertical": "Finance",
        "total_revenue": 2700.0,
        "top_publishers": [ ... ]
      }
    ],
    "os": [
      {
        "os": "Android",
        "total_revenue": 5440.0,
        "top_publishers": [ ... ]
      }
    ]
  },
  "summary": {
    "total_revenue": 12345.67,
    "total_records": 250,
    "unique_publishers": 18,
    "date_range": { "from": "2024-01-01", "to": "2024-02-01" }
  },
  "meta": {
    "user_id": 1,
    "role": "admin",
    "filters": { "month": "2024-01", "geo": null, "vertical": null, "os": null },
    "pagination": { "page": 1, "page_size": 15 },
    "cached": false,
    "duration_ms": 48,
    "generated_at": "2024-03-01T12:00:00.000Z"
  }
}
```

---

### `GET /api/v1/health`

Liveness probe. No authentication required.

```json
{
  "status": "ok",
  "uptime_seconds": 3600,
  "cache_stats": { "hits": 12, "misses": 4, "keys": 6 },
  "timestamp": "2024-03-01T12:00:00.000Z"
}
```

---

### `POST /api/v1/analytics/cache/flush`

Invalidates the analytics cache. Admin only.

```bash
POST /api/v1/analytics/cache/flush?user_id=1&role=admin
```

---

## Role-Based Access Control

| Role                | Data Visible                              |
|---------------------|-------------------------------------------|
| `publisher`         | Own rows only (`pub_id = user_id`)        |
| `publisher_manager` | Own rows + all assigned publishers        |
| `admin`             | All rows (no restriction)                 |

Manager assignments are stored in `publisher_assignments(manager_id, publisher_id)`.

---

## Revenue Formula

```
revenue = SUM(pub_payout * pub_apno)
```

Applied entirely in SQL via `SUM(cp.pub_payout * cp.pub_apno) AS revenue`.

---

## Ranking Logic

Publishers within each category (GEO, Vertical, OS) are ranked using SQL `RANK()`:

```sql
RANK() OVER (PARTITION BY geo ORDER BY revenue DESC)
```

Ties share a rank (e.g., two publishers at equal revenue both get rank 1, next is rank 3).

---

## OS Handling

OS values are stored as comma-separated strings (`"Android,iOS"`).  
The API splits them in JavaScript post-query, credits each OS independently,
then re-aggregates and ranks. The top 10 OSes by total revenue are returned.

---

## Caching

- TTL: 5 minutes (configurable via `CACHE_TTL_SECONDS`)
- Scope: Per unique combination of `(role, user_id, month, geo, vertical, os, page)`
- The `meta.cached: true` flag indicates a cache hit
- Flush via `POST /api/v1/analytics/cache/flush` (admin only)

---

## Index Strategy

```sql
-- campaign_performance
INDEX idx_geo_month_pub   (geo, month, pub_id)   -- GEO analytics
INDEX idx_vertical_month  (vertical, month, pub_id) -- Vertical analytics
INDEX idx_pub_id          (pub_id)               -- Role-based filtering
INDEX idx_status          (status)               -- Status filter
INDEX idx_month           (month)                -- Date range queries

-- publisher_assignments
INDEX idx_pa_manager      (manager_id)           -- Manager → publisher lookup
INDEX idx_pa_publisher    (publisher_id)          -- Publisher → manager lookup
```
