/**
 * utils/queryBuilder.js
 * ──────────────────────────────────────────────────────────────────────────────
 * Builds reusable, parameterised WHERE clause fragments.
 *
 * All values are passed as bound parameters (never interpolated) to prevent
 * SQL injection. mysql2 uses "?" placeholders with an ordered params array.
 */

"use strict";

/**
 * buildWhereClause(filters, allowedPublishers, tableAlias?)
 *
 * Constructs the WHERE clause conditions and the matching params array.
 *
 * @param {object}        filters
 * @param {string|null}   filters.month     - "YYYY-MM" or null
 * @param {string|null}   filters.geo
 * @param {string|null}   filters.vertical
 * @param {string|null}   filters.os
 * @param {number[]|null} allowedPublishers  - null = no restriction (admin)
 * @param {string}        [alias="cp"]       - Table alias used in query
 *
 * @returns {{ conditions: string[], params: any[] }}
 */
function buildWhereClause(filters, allowedPublishers, alias = "cp") {
  const conditions = [];
  const params     = [];

  // ── Role-based publisher filter ───────────────────────────────────────────
  if (allowedPublishers !== null) {
    if (allowedPublishers.length === 0) {
      // Edge case: manager with no assigned publishers — return nothing
      conditions.push("1 = 0");
    } else if (allowedPublishers.length === 1) {
      conditions.push(`${alias}.pub_id = ?`);
      params.push(allowedPublishers[0]);
    } else {
      // IN clause — mysql2 handles array expansion automatically
      conditions.push(`${alias}.pub_id IN (?)`);
      params.push(allowedPublishers);
    }
  }

  // ── Optional filters ──────────────────────────────────────────────────────

  // month: stored as DATE or VARCHAR "YYYY-MM-DD"; match on year-month prefix
  if (filters.month) {
    conditions.push(`DATE_FORMAT(${alias}.month, '%Y-%m') = ?`);
    params.push(filters.month);
  }

  if (filters.geo) {
    conditions.push(`${alias}.geo = ?`);
    params.push(filters.geo);
  }

  // vertical can be NULL in the database — filter only hits non-NULL rows
  if (filters.vertical) {
    conditions.push(`${alias}.vertical = ?`);
    params.push(filters.vertical);
  }

  // OS is multi-value "Android,iOS" — handled per-query (see analyticsService)

  return { conditions, params };
}

/**
 * toWhereSQL(conditions)
 * Converts a conditions array to a SQL WHERE string (or "" if empty).
 */
function toWhereSQL(conditions) {
  if (!conditions.length) return "";
  return "WHERE " + conditions.join(" AND ");
}

module.exports = { buildWhereClause, toWhereSQL };
