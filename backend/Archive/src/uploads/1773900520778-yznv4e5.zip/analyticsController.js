/**
 * controllers/analyticsController.js
 * ──────────────────────────────────────────────────────────────────────────────
 * Handles GET /analytics requests.
 *
 * Flow:
 *   1. Read actor (set by RBAC middleware) and filters
 *   2. Check cache — return immediately on hit
 *   3. Resolve allowed publisher IDs (accessService)
 *   4. Run GEO, Vertical, OS, and Summary queries in parallel
 *   5. Assemble and cache the response
 *   6. Return structured JSON
 */

"use strict";

const { resolveAllowedPublishers } = require("../services/accessService");
const { getTopGeo, getTopVertical, getTopOS, getSummaryStats } =
  require("../services/analyticsService");
const cache = require("../utils/cache");

/**
 * GET /analytics
 *
 * Query params (validated upstream by middleware):
 *   user_id      (required)
 *   role         (required: publisher | publisher_manager | admin)
 *   month        (optional: YYYY-MM)
 *   geo          (optional)
 *   vertical     (optional)
 *   os           (optional)
 *   page         (optional: default 1)
 *   page_size    (optional: default 15, max 100)
 */
async function getAnalytics(req, res) {
  const { actor, filters } = req;
  const startTime = Date.now();

  try {
    // ── Cache lookup ────────────────────────────────────────────────────────
    const cacheParams = { ...filters, role: actor.role, userId: actor.userId };
    const cached = cache.get(cacheParams);

    if (cached) {
      return res.json({
        ...cached,
        meta: { ...cached.meta, cached: true, duration_ms: Date.now() - startTime },
      });
    }

    // ── Resolve data access scope ───────────────────────────────────────────
    const allowedPublishers = await resolveAllowedPublishers(actor);

    // ── Run all analytics queries in parallel ───────────────────────────────
    const [geoData, verticalData, osData, summary] = await Promise.all([
      getTopGeo(filters, allowedPublishers),
      getTopVertical(filters, allowedPublishers),
      getTopOS(filters, allowedPublishers),
      getSummaryStats(filters, allowedPublishers),
    ]);

    // ── Assemble response ───────────────────────────────────────────────────
    const response = {
      success: true,
      data: {
        geo:      geoData,
        vertical: verticalData,
        os:       osData,
      },
      summary,
      meta: {
        user_id:    actor.userId,
        role:       actor.role,
        filters: {
          month:    filters.month    || null,
          geo:      filters.geo      || null,
          vertical: filters.vertical || null,
          os:       filters.os       || null,
        },
        pagination: {
          page:      filters.page,
          page_size: filters.pageSize,
        },
        cached:      false,
        duration_ms: Date.now() - startTime,
        generated_at: new Date().toISOString(),
      },
    };

    // ── Cache the result ────────────────────────────────────────────────────
    cache.set(cacheParams, response);

    return res.json(response);

  } catch (err) {
    console.error("[analyticsController] Error:", {
      message:  err.message,
      userId:   actor?.userId,
      role:     actor?.role,
      filters,
      stack:    process.env.NODE_ENV === "development" ? err.stack : undefined,
    });

    return res.status(500).json({
      success: false,
      error:   "Failed to generate analytics report",
      // Only expose details in development
      detail:  process.env.NODE_ENV === "development" ? err.message : undefined,
    });
  }
}

/**
 * POST /analytics/cache/flush
 * Admin-only endpoint to invalidate the analytics cache after data imports.
 */
async function flushCache(req, res) {
  if (req.actor?.role !== "admin") {
    return res.status(403).json({ success: false, error: "Admin access required" });
  }
  cache.flush();
  return res.json({ success: true, message: "Cache flushed" });
}

/**
 * GET /health
 * Liveness probe — returns server status and cache stats.
 */
async function healthCheck(req, res) {
  return res.json({
    status: "ok",
    uptime_seconds: Math.floor(process.uptime()),
    cache_stats:    cache.stats(),
    timestamp:      new Date().toISOString(),
  });
}

module.exports = { getAnalytics, flushCache, healthCheck };
