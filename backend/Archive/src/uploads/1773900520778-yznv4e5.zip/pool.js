/**
 * db/pool.js
 * ──────────────────────────────────────────────────────────────────────────────
 * Creates and exports a shared MySQL2 connection pool.
 * Using a pool (not single connections) is critical for production:
 *   - Reuses connections instead of opening/closing per request
 *   - Handles concurrency automatically
 *   - Built-in connection retry on transient failures
 */

"use strict";

require("dotenv").config();
const mysql = require("mysql2/promise");

// ─── Pool Configuration ───────────────────────────────────────────────────────

const pool = mysql.createPool({
  host:               process.env.DB_HOST     || "localhost",
  port:               parseInt(process.env.DB_PORT || "3306", 10),
  user:               process.env.DB_USER     || "root",
  password:           process.env.DB_PASSWORD || "",
  database:           process.env.DB_NAME     || "campaign_db",
  connectionLimit:    parseInt(process.env.DB_CONNECTION_LIMIT || "10", 10),
  waitForConnections: true,     // Queue requests when pool is exhausted
  queueLimit:         0,        // 0 = unlimited queue
  charset:            "utf8mb4",

  // Keep connections alive (avoids "connection lost" on idle)
  enableKeepAlive:    true,
  keepAliveInitialDelay: 30000, // 30 s

  // Automatically convert MySQL date/time types to JS Date objects
  dateStrings: false,

  // Timezone — store/retrieve timestamps in UTC
  timezone: "Z",
});

// ─── Health Check ─────────────────────────────────────────────────────────────

/**
 * Ping the database to verify connectivity.
 * Called during server startup — process exits on failure.
 */
async function testConnection() {
  let conn;
  try {
    conn = await pool.getConnection();
    await conn.ping();
    console.log("✔ MySQL connection pool established");
  } catch (err) {
    console.error("✖ MySQL connection failed:", err.message);
    process.exit(1); // Hard fail — don't start a broken server
  } finally {
    if (conn) conn.release();
  }
}

module.exports = { pool, testConnection };
