/**
 * services/accessService.js
 * ──────────────────────────────────────────────────────────────────────────────
 * Resolves which publisher IDs the requesting actor is allowed to query.
 *
 * Role matrix:
 *   publisher          → [userId]             (own data only)
 *   publisher_manager  → [userId, ...assigned] (own + assigned publishers)
 *   admin              → null                  (null = no filter, see all)
 *
 * The returned value is injected directly into SQL WHERE clauses:
 *   null   → no pub_id restriction (admin)
 *   number[] → WHERE pub_id IN (...)
 */

"use strict";

const { pool } = require("../db/pool");

/**
 * resolveAllowedPublishers(actor)
 *
 * @param {{ userId: number, role: string }} actor
 * @returns {Promise<number[]|null>}
 *   - null   → admin (unrestricted)
 *   - number[] → allowed pub_id list
 */
async function resolveAllowedPublishers(actor) {
  const { userId, role } = actor;

  switch (role) {
    // ── Publisher: only their own row ────────────────────────────────────────
    case "publisher":
      return [userId];

    // ── Publisher Manager: own + assigned publishers ──────────────────────
    case "publisher_manager": {
      const [rows] = await pool.execute(
        // INDEX SUGGESTION: CREATE INDEX idx_pa_manager ON publisher_assignments(manager_id);
        `SELECT publisher_id FROM publisher_assignments WHERE manager_id = ?`,
        [userId]
      );
      const assignedIds = rows.map((r) => r.publisher_id);
      // Manager can also see their own performance if they're also a publisher
      return [...new Set([userId, ...assignedIds])];
    }

    // ── Admin: unrestricted ───────────────────────────────────────────────
    case "admin":
    default:
      return null; // null signals "no filter" to query builders
  }
}

module.exports = { resolveAllowedPublishers };
