/**
 * utils/cache.js
 * ──────────────────────────────────────────────────────────────────────────────
 * Thin wrapper around node-cache for analytics result caching.
 *
 * Why cache analytics?
 *   - Analytics queries aggregate millions of rows with GROUP BY + RANK.
 *   - Results change infrequently (usually per-day / per-hour).
 *   - Caching cuts DB load dramatically on a busy dashboard.
 *
 * Cache key strategy:
 *   analytics:{role}:{userId}:{month}:{geo}:{vertical}:{os}:{page}
 */

"use strict";

require("dotenv").config();
const NodeCache = require("node-cache");

const cache = new NodeCache({
  stdTTL:      parseInt(process.env.CACHE_TTL_SECONDS    || "300", 10),
  checkperiod: parseInt(process.env.CACHE_CHECK_PERIOD   || "60",  10),
  useClones:   false, // Skip deep-clone overhead; callers must not mutate cached objects
});

/**
 * Build a deterministic cache key from a params object.
 * All undefined values are normalised to "" so key is stable.
 *
 * @param {object} params
 * @returns {string}
 */
function buildKey(params) {
  const { role, userId, month, geo, vertical, os, page } = params;
  return [
    "analytics",
    role    || "all",
    userId  || "all",
    month   || "all",
    geo     || "all",
    vertical|| "all",
    os      || "all",
    page    || "1",
  ].join(":");
}

/**
 * Retrieve a cached value. Returns undefined on miss.
 */
function get(params) {
  return cache.get(buildKey(params));
}

/**
 * Store a value. TTL falls back to the NodeCache default (stdTTL).
 */
function set(params, value, ttl) {
  cache.set(buildKey(params), value, ttl);
}

/**
 * Delete a single cache entry.
 */
function del(params) {
  cache.del(buildKey(params));
}

/**
 * Wipe all cached analytics (e.g., after a data import).
 */
function flush() {
  cache.flushAll();
  console.log("Cache flushed");
}

/** Expose raw cache stats for a /health or /debug endpoint. */
function stats() {
  return cache.getStats();
}

module.exports = { get, set, del, flush, stats, buildKey };
