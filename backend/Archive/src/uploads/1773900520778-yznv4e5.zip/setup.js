/**
 * sql/setup.js
 * ──────────────────────────────────────────────────────────────────────────────
 * Database bootstrapper — creates tables and indexes if they don't exist.
 *
 * Run once:
 *   node sql/setup.js
 *
 * Idempotent: uses IF NOT EXISTS everywhere — safe to re-run.
 */

"use strict";

require("dotenv").config({ path: require("path").resolve(__dirname, "../.env") });
const { pool, testConnection } = require("../src/db/pool");

const SCHEMA = `
-- ─── campaign_performance ─────────────────────────────────────────────────────
-- Core fact table. One row = one publisher's performance on one campaign/month.
CREATE TABLE IF NOT EXISTS campaign_performance (
  id                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  pub_id            INT UNSIGNED     NOT NULL,
  month             DATE             NOT NULL COMMENT 'Stored as first day of month: YYYY-MM-01',
  campaign_name     VARCHAR(255)     NOT NULL,
  vertical          VARCHAR(100)     DEFAULT NULL COMMENT 'Can be NULL — excluded from vertical analytics',
  geo               CHAR(2)          NOT NULL    COMMENT 'ISO 3166-1 alpha-2 country code',
  os                VARCHAR(100)     NOT NULL    COMMENT 'Comma-separated: Android,iOS',
  payable_event     VARCHAR(100)     NOT NULL,
  pub_payout        DECIMAL(18, 6)   NOT NULL DEFAULT 0.000000,
  adv_total_number  INT UNSIGNED     NOT NULL DEFAULT 0,
  pub_apno          INT UNSIGNED     NOT NULL DEFAULT 0,
  status            ENUM('active','paused','ended') NOT NULL DEFAULT 'active',
  created_at        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),

  -- ── Indexes optimised for analytics query patterns ────────────────────────
  -- Covering index for revenue aggregation filtered by month + geo
  INDEX idx_geo_month_pub   (geo, month, pub_id),
  -- Covering index for vertical analytics
  INDEX idx_vertical_month  (vertical, month, pub_id),
  -- Index for role-based filtering (publisher sees own rows)
  INDEX idx_pub_id          (pub_id),
  -- Index for status filter (most queries exclude non-active rows)
  INDEX idx_status          (status),
  -- Composite for date range queries
  INDEX idx_month           (month)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── publisher_assignments ────────────────────────────────────────────────────
-- Maps a publisher_manager to the publishers they oversee.
CREATE TABLE IF NOT EXISTS publisher_assignments (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  manager_id    INT UNSIGNED NOT NULL COMMENT 'References a user with role=publisher_manager',
  publisher_id  INT UNSIGNED NOT NULL COMMENT 'References a user with role=publisher',
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_manager_publisher (manager_id, publisher_id),

  -- Fast lookup of all publishers for a given manager
  INDEX idx_pa_manager (manager_id),
  -- Reverse lookup: which manager owns this publisher?
  INDEX idx_pa_publisher (publisher_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
`;

const SEED_DATA = `
-- ─── Sample data for local development / testing ─────────────────────────────
INSERT IGNORE INTO publisher_assignments (manager_id, publisher_id) VALUES
  (100, 1), (100, 2), (100, 3),
  (101, 4), (101, 5);

INSERT IGNORE INTO campaign_performance
  (pub_id, month, campaign_name, vertical, geo, os, payable_event, pub_payout, adv_total_number, pub_apno, status)
VALUES
  (1, '2024-01-01', 'Alpha Campaign',   'Finance',    'US', 'Android',      'install', 1.50, 1000, 800,  'active'),
  (1, '2024-01-01', 'Beta Campaign',    'Gaming',     'MX', 'iOS',          'signup',  2.00, 500,  420,  'active'),
  (2, '2024-01-01', 'Gamma Campaign',   'eCommerce',  'IN', 'Android,iOS',  'purchase',3.00, 800,  600,  'active'),
  (3, '2024-01-01', 'Delta Campaign',   NULL,         'BR', 'Android',      'install', 0.80, 1200, 900,  'active'),
  (4, '2024-01-01', 'Epsilon Campaign', 'Finance',    'US', 'iOS',          'install', 2.50, 700,  550,  'active'),
  (5, '2024-01-01', 'Zeta Campaign',    'Gaming',     'DE', 'Android',      'signup',  1.80, 300,  250,  'active'),
  (1, '2024-02-01', 'Alpha Campaign',   'Finance',    'US', 'Android',      'install', 1.50, 1100, 900,  'active'),
  (2, '2024-02-01', 'Theta Campaign',   'eCommerce',  'MX', 'iOS',          'purchase',3.50, 400,  380,  'active'),
  (3, '2024-02-01', 'Iota Campaign',    'Travel',     'GB', 'Android,iOS',  'booking', 5.00, 200,  180,  'active'),
  (5, '2024-02-01', 'Kappa Campaign',   'Gaming',     'DE', 'Android',      'signup',  1.80, 350,  300,  'active');
`;

async function setup() {
  await testConnection();
  const conn = await pool.getConnection();

  try {
    console.log("Creating tables...");
    // Execute each statement separately (mysql2 doesn't support multi-statement by default)
    const statements = SCHEMA
      .split(";")
      .map((s) => s.trim())
      .filter(Boolean);

    for (const stmt of statements) {
      await conn.execute(stmt);
    }
    console.log("✔ Schema applied");

    if (process.env.NODE_ENV !== "production") {
      console.log("Inserting seed data...");
      const seedStmts = SEED_DATA
        .split(";")
        .map((s) => s.trim())
        .filter(Boolean);

      for (const stmt of seedStmts) {
        await conn.execute(stmt);
      }
      console.log("✔ Seed data inserted");
    }

    console.log("\n✅ Database setup complete");
  } finally {
    conn.release();
    process.exit(0);
  }
}

setup().catch((err) => {
  console.error("✖ Setup failed:", err.message);
  process.exit(1);
});
