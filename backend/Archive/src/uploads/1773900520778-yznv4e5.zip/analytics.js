/**
 * routes/analytics.js
 * ──────────────────────────────────────────────────────────────────────────────
 * Route definitions for the analytics API.
 *
 * Middleware chain per route:
 *   validateRoleAccess → validateFilters → controller
 *
 * This keeps controllers clean (no validation logic) and makes the chain
 * easy to extend (e.g., add rate limiting per route, JWT auth, etc.).
 */

"use strict";

const express = require("express");
const router  = express.Router();

const { validateRoleAccess, validateFilters } = require("../middleware/rbac");
const { getAnalytics, flushCache, healthCheck } = require("../controllers/analyticsController");

// ── Public Routes ──────────────────────────────────────────────────────────────

/**
 * GET /health
 * Liveness/readiness probe — no auth required.
 */
router.get("/health", healthCheck);

// ── Analytics Routes ───────────────────────────────────────────────────────────

/**
 * GET /analytics
 *
 * Query params:
 *   user_id      {number}  required
 *   role         {string}  required  publisher | publisher_manager | admin
 *   month        {string}  optional  YYYY-MM
 *   geo          {string}  optional
 *   vertical     {string}  optional
 *   os           {string}  optional
 *   page         {number}  optional  default: 1
 *   page_size    {number}  optional  default: 15 (max 100)
 *
 * Example:
 *   GET /analytics?user_id=42&role=publisher_manager&month=2024-01&geo=IN
 */
router.get(
  "/analytics",
  validateRoleAccess,   // Validates user_id + role, attaches req.actor
  validateFilters,      // Validates optional params, attaches req.filters
  getAnalytics
);

/**
 * POST /analytics/cache/flush
 * Invalidate the analytics cache (admin only).
 * Useful after bulk data imports.
 */
router.post(
  "/analytics/cache/flush",
  validateRoleAccess,   // Still requires a valid actor (admin check is in controller)
  flushCache
);

module.exports = router;
