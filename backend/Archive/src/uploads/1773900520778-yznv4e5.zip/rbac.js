/**
 * middleware/rbac.js
 * ──────────────────────────────────────────────────────────────────────────────
 * Role-Based Access Control (RBAC) middleware.
 *
 * Validates that `user_id` and `role` query params are present and valid
 * before the request reaches the controller.
 *
 * Valid roles:
 *   publisher          → sees only their own data
 *   publisher_manager  → sees their data + assigned publishers
 *   admin              → sees all data
 */

"use strict";

const VALID_ROLES = new Set(["publisher", "publisher_manager", "admin"]);

/**
 * validateRoleAccess
 *
 * Express middleware that:
 *   1. Ensures `user_id` and `role` are present in the query string
 *   2. Validates the role value
 *   3. Attaches a normalised `req.actor` object for downstream use
 */
function validateRoleAccess(req, res, next) {
  const { user_id, role } = req.query;

  // ── Presence checks ──────────────────────────────────────────────────────
  if (!user_id) {
    return res.status(400).json({
      success: false,
      error: "Missing required query parameter: user_id",
    });
  }

  if (!role) {
    return res.status(400).json({
      success: false,
      error: "Missing required query parameter: role",
    });
  }

  // ── Role validation ───────────────────────────────────────────────────────
  const normalizedRole = role.toLowerCase().trim();
  if (!VALID_ROLES.has(normalizedRole)) {
    return res.status(403).json({
      success: false,
      error: `Invalid role "${role}". Must be one of: ${[...VALID_ROLES].join(", ")}`,
    });
  }

  // ── Attach actor context ──────────────────────────────────────────────────
  // Controllers and services read from req.actor — never raw req.query
  req.actor = {
    userId: parseInt(user_id, 10) || user_id, // Coerce to int if numeric
    role:   normalizedRole,
  };

  next();
}

/**
 * validateFilters
 *
 * Light validation middleware for optional analytics filter params.
 * Rejects obviously malformed values to prevent SQL injection surface.
 */
function validateFilters(req, res, next) {
  const { month, geo, vertical, os, page, page_size } = req.query;

  // month must match YYYY-MM if provided
  if (month && !/^\d{4}-\d{2}$/.test(month)) {
    return res.status(400).json({
      success: false,
      error: 'Invalid "month" format. Expected YYYY-MM (e.g., 2024-01)',
    });
  }

  // page must be a positive integer
  if (page !== undefined) {
    const p = parseInt(page, 10);
    if (isNaN(p) || p < 1) {
      return res.status(400).json({
        success: false,
        error: '"page" must be a positive integer',
      });
    }
  }

  // page_size must be 1–100
  if (page_size !== undefined) {
    const ps = parseInt(page_size, 10);
    if (isNaN(ps) || ps < 1 || ps > 100) {
      return res.status(400).json({
        success: false,
        error: '"page_size" must be between 1 and 100',
      });
    }
  }

  // Attach parsed filters to req for downstream use
  req.filters = {
    month:    month    || null,
    geo:      geo      || null,
    vertical: vertical || null,
    os:       os       || null,
    page:     parseInt(page      || "1",  10),
    pageSize: parseInt(page_size || "15", 10),
  };

  next();
}

module.exports = { validateRoleAccess, validateFilters };
