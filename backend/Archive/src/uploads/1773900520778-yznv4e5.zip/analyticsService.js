/**
 * services/analyticsService.js
 * ──────────────────────────────────────────────────────────────────────────────
 * Core analytics engine.
 *
 * Responsibilities:
 *   1. Run the three category queries (GEO, Vertical, OS) in parallel
 *   2. Rank publishers within each category using SQL RANK()
 *   3. Handle multi-value OS ("Android,iOS") by exploding rows in JS
 *   4. Produce a summary stats block
 *
 * Revenue formula (applied entirely in SQL):
 *   revenue = SUM(pub_payout * pub_apno)
 *
 * Ranking:
 *   Uses CTE + RANK() OVER (PARTITION BY category ORDER BY revenue DESC)
 *   so ties share a rank (RANK vs ROW_NUMBER is intentional — rank 1,1,3).
 */

"use strict";

const { pool }          = require("../db/pool");
const { buildWhereClause, toWhereSQL } = require("../utils/queryBuilder");

// ─── Constants ────────────────────────────────────────────────────────────────

const TOP_CATEGORIES    = 10;  // Top N GEOs / Verticals / OSes
const TOP_PUBLISHERS    = 15;  // Top N publishers per category

// ─── GEO Analytics ───────────────────────────────────────────────────────────

/**
 * getTopGeo(filters, allowedPublishers)
 *
 * Returns top 10 GEOs by revenue, each with top 15 ranked publishers.
 *
 * CTE strategy:
 *   1. pub_revenue   → revenue per (geo, pub_id)
 *   2. geo_total     → total revenue per geo
 *   3. geo_ranked    → rank publishers within each geo
 *
 * @param {object}        filters
 * @param {number[]|null} allowedPublishers
 * @returns {Promise<object[]>}
 */
async function getTopGeo(filters, allowedPublishers) {
  const { conditions, params } = buildWhereClause(filters, allowedPublishers, "cp");
  const whereSQL = toWhereSQL([
    ...conditions,
    "cp.geo IS NOT NULL",   // Exclude rows with no GEO
    "cp.status = 'active'", // Only active campaigns
  ]);

  // We need params twice: once for pub_revenue CTE, once for geo_total CTE
  const sql = `
    WITH pub_revenue AS (
      -- Aggregate revenue per publisher per GEO
      SELECT
        cp.geo,
        cp.pub_id,
        SUM(cp.pub_payout * cp.pub_apno) AS revenue
      FROM campaign_performance cp
      ${whereSQL}
      GROUP BY cp.geo, cp.pub_id
    ),
    geo_total AS (
      -- Roll up to total revenue per GEO
      SELECT
        geo,
        SUM(revenue) AS total_revenue
      FROM pub_revenue
      GROUP BY geo
      ORDER BY total_revenue DESC
      LIMIT ${TOP_CATEGORIES}
    ),
    geo_ranked AS (
      -- Rank publishers within each GEO using RANK() (ties share a rank)
      SELECT
        pr.geo,
        pr.pub_id,
        pr.revenue,
        RANK() OVER (PARTITION BY pr.geo ORDER BY pr.revenue DESC) AS \`rank\`
      FROM pub_revenue pr
      -- Only include GEOs that made the top 10
      INNER JOIN geo_total gt ON pr.geo = gt.geo
    )
    SELECT
      gt.geo,
      gt.total_revenue,
      gr.pub_id,
      gr.revenue       AS publisher_revenue,
      gr.\`rank\`
    FROM geo_total gt
    LEFT JOIN geo_ranked gr
      ON gt.geo = gr.geo AND gr.\`rank\` <= ${TOP_PUBLISHERS}
    ORDER BY gt.total_revenue DESC, gr.\`rank\` ASC
  `;

  // params used once (WHERE clause is only in pub_revenue CTE)
  const [rows] = await pool.execute(sql, params);
  return groupByCategory(rows, "geo");
}

// ─── Vertical Analytics ───────────────────────────────────────────────────────

/**
 * getTopVertical(filters, allowedPublishers)
 *
 * Same pattern as GEO but grouped by vertical.
 * NULL verticals are excluded (COALESCE could label them "Unknown" if needed).
 */
async function getTopVertical(filters, allowedPublishers) {
  const { conditions, params } = buildWhereClause(filters, allowedPublishers, "cp");
  const whereSQL = toWhereSQL([
    ...conditions,
    "cp.vertical IS NOT NULL",  // Exclude NULL verticals per requirements
    "cp.status = 'active'",
  ]);

  const sql = `
    WITH pub_revenue AS (
      SELECT
        cp.vertical,
        cp.pub_id,
        SUM(cp.pub_payout * cp.pub_apno) AS revenue
      FROM campaign_performance cp
      ${whereSQL}
      GROUP BY cp.vertical, cp.pub_id
    ),
    vertical_total AS (
      SELECT
        vertical,
        SUM(revenue) AS total_revenue
      FROM pub_revenue
      GROUP BY vertical
      ORDER BY total_revenue DESC
      LIMIT ${TOP_CATEGORIES}
    ),
    vertical_ranked AS (
      SELECT
        pr.vertical,
        pr.pub_id,
        pr.revenue,
        RANK() OVER (PARTITION BY pr.vertical ORDER BY pr.revenue DESC) AS \`rank\`
      FROM pub_revenue pr
      INNER JOIN vertical_total vt ON pr.vertical = vt.vertical
    )
    SELECT
      vt.vertical,
      vt.total_revenue,
      vr.pub_id,
      vr.revenue       AS publisher_revenue,
      vr.\`rank\`
    FROM vertical_total vt
    LEFT JOIN vertical_ranked vr
      ON vt.vertical = vr.vertical AND vr.\`rank\` <= ${TOP_PUBLISHERS}
    ORDER BY vt.total_revenue DESC, vr.\`rank\` ASC
  `;

  const [rows] = await pool.execute(sql, params);
  return groupByCategory(rows, "vertical");
}

// ─── OS Analytics ─────────────────────────────────────────────────────────────

/**
 * getTopOS(filters, allowedPublishers)
 *
 * OS is stored as a comma-separated string ("Android,iOS").
 * Strategy:
 *   1. Fetch raw (os, pub_id, revenue) rows from MySQL
 *   2. In JavaScript, explode each row by splitting os on ","
 *   3. Re-aggregate revenue per (normalised_os, pub_id) in a Map
 *   4. Apply the same top-10 / top-15 / ranking logic in JS
 *
 * Why not split in SQL?
 *   MySQL 5.x lacks JSON_TABLE / SUBSTRING_INDEX multi-split support.
 *   MySQL 8+ has JSON_TABLE but it's verbose and not universally available.
 *   The JS approach is simpler, testable, and DB-version agnostic.
 *
 * Optional OS filter: if filters.os is set, we apply it AFTER splitting.
 */
async function getTopOS(filters, allowedPublishers) {
  const { conditions, params } = buildWhereClause(
    { ...filters, os: null }, // OS filter applied post-split in JS
    allowedPublishers,
    "cp"
  );
  const whereSQL = toWhereSQL([
    ...conditions,
    "cp.os IS NOT NULL",
    "cp.status = 'active'",
  ]);

  const sql = `
    SELECT
      cp.os,
      cp.pub_id,
      SUM(cp.pub_payout * cp.pub_apno) AS revenue
    FROM campaign_performance cp
    ${whereSQL}
    GROUP BY cp.os, cp.pub_id
  `;

  const [rawRows] = await pool.execute(sql, params);

  // ── Explode multi-value OS ─────────────────────────────────────────────────
  // Map structure: osName → Map<pubId, revenue>
  const osMap = new Map();

  for (const row of rawRows) {
    const osList = row.os
      .split(",")
      .map((o) => o.trim())
      .filter(Boolean);

    for (const osName of osList) {
      // Apply optional OS filter (case-insensitive)
      if (filters.os && osName.toLowerCase() !== filters.os.toLowerCase()) {
        continue;
      }

      if (!osMap.has(osName)) {
        osMap.set(osName, new Map());
      }

      const pubMap = osMap.get(osName);
      const current = pubMap.get(row.pub_id) || 0;
      // Revenue is already aggregated per (raw_os, pub_id) — add proportionally
      // Since one row may cover "Android,iOS", we credit full revenue to each OS.
      // For production, ideally OS should be normalised at ingestion time.
      pubMap.set(row.pub_id, current + parseFloat(row.revenue));
    }
  }

  // ── Aggregate total revenue per OS, sort descending ───────────────────────
  const osEntries = [];

  for (const [osName, pubMap] of osMap.entries()) {
    let totalRevenue = 0;
    const publishers = [];

    for (const [pubId, revenue] of pubMap.entries()) {
      totalRevenue += revenue;
      publishers.push({ pub_id: pubId, revenue: parseFloat(revenue.toFixed(4)) });
    }

    // Rank publishers by revenue within this OS
    publishers.sort((a, b) => b.revenue - a.revenue);
    publishers.forEach((p, idx) => { p.rank = idx + 1; });

    osEntries.push({
      os:              osName,
      total_revenue:   parseFloat(totalRevenue.toFixed(4)),
      top_publishers:  publishers.slice(0, TOP_PUBLISHERS),
    });
  }

  // Return top 10 OSes by total revenue
  osEntries.sort((a, b) => b.total_revenue - a.total_revenue);
  return osEntries.slice(0, TOP_CATEGORIES);
}

// ─── Summary Stats ────────────────────────────────────────────────────────────

/**
 * getSummaryStats(filters, allowedPublishers)
 *
 * Returns a top-level summary block:
 *   total_revenue, total_records, unique_publishers, date_range
 */
async function getSummaryStats(filters, allowedPublishers) {
  const { conditions, params } = buildWhereClause(filters, allowedPublishers, "cp");
  const whereSQL = toWhereSQL([...conditions, "cp.status = 'active'"]);

  const sql = `
    SELECT
      SUM(cp.pub_payout * cp.pub_apno)          AS total_revenue,
      COUNT(*)                                   AS total_records,
      COUNT(DISTINCT cp.pub_id)                  AS unique_publishers,
      MIN(cp.month)                              AS date_from,
      MAX(cp.month)                              AS date_to
    FROM campaign_performance cp
    ${whereSQL}
  `;

  const [rows] = await pool.execute(sql, params);
  const r = rows[0] || {};

  return {
    total_revenue:      parseFloat((r.total_revenue || 0).toFixed(4)),
    total_records:      parseInt(r.total_records    || 0, 10),
    unique_publishers:  parseInt(r.unique_publishers|| 0, 10),
    date_range: {
      from: r.date_from || null,
      to:   r.date_to   || null,
    },
  };
}

// ─── Helper: Group flat SQL rows into nested category objects ─────────────────

/**
 * groupByCategory(rows, categoryKey)
 *
 * SQL JOINs return flat rows; this groups them into:
 *   [{ [categoryKey]: "MX", total_revenue: 12345, top_publishers: [...] }]
 *
 * @param {object[]} rows
 * @param {string}   categoryKey - "geo" | "vertical"
 * @returns {object[]}
 */
function groupByCategory(rows, categoryKey) {
  const map = new Map();

  for (const row of rows) {
    const key = row[categoryKey];

    if (!map.has(key)) {
      map.set(key, {
        [categoryKey]:  key,
        total_revenue:  parseFloat((row.total_revenue || 0).toFixed(4)),
        top_publishers: [],
      });
    }

    // A LEFT JOIN row with no matching publisher has null pub_id
    if (row.pub_id != null) {
      map.get(key).top_publishers.push({
        pub_id:  row.pub_id,
        revenue: parseFloat((row.publisher_revenue || 0).toFixed(4)),
        rank:    row.rank,
      });
    }
  }

  return [...map.values()];
}

// ─── Main Export ──────────────────────────────────────────────────────────────

module.exports = { getTopGeo, getTopVertical, getTopOS, getSummaryStats };
